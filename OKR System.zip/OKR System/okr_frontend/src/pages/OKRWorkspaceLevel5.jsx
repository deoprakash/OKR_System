import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import BackButton from '../components/BackButton';
import FormRow from '../components/FormRow';
import LabeledInput from '../components/LabeledInput';
import KeyResultInput from '../components/KeyResultInput';
import QuarterInput from '../components/QuarterInput';
import OKRActionButton from '../components/OKRActionButton';
import OKRLevelSection from '../components/OKRLevelSection';
import SectionTitle from '../components/SectionTitle';
import Box from '../components/Box';
import { listEmployees, listLevel4OKRs, listLevel5OKRs, createLevel5OKR, updateLevel5OKR } from '../lib/api';
import { useToast } from '../components/ToastProvider';

const OKRWorkspaceLevel5 = () => {
  const navigate = useNavigate();
  const toast = useToast();
  const getLocalDateString = (value) => {
    const d = value ? new Date(value) : new Date();
    if (Number.isNaN(d.getTime())) return '';
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };
  const [fields, setFields] = useState({
    employeeCode: '',
    employeeName: '',
    employeeUserId: '',
    employeeLevel: '',
    okrCode: '',
    okrDate: '',
    okrDescription: '',
    keyResults: Array(5).fill(''),
    quarters: [
      { percent: '', comment: '' },
      { percent: '', comment: '' },
      { percent: '', comment: '' },
      { percent: '', comment: '' },
    ],
    level4EmployeeCode: '',
    level4EmployeeName: '',
    level4EmployeeUserId: '',
    level4OKRDescription: '',
    level4OkrCode: '',
  });
  const [employeeOptions, setEmployeeOptions] = useState([]);
  const [level4Options, setLevel4Options] = useState([]);
  const [level4OKRDescriptions, setLevel4OKRDescriptions] = useState([]);
  const [level5All, setLevel5All] = useState([]);
  const [canClose, setCanClose] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const pristineRef = useRef(null);
  const _initRef = useRef(false);
  const sumPercents = () => fields.quarters.reduce((s, q) => s + (Number(q.percent) || 0), 0);
  const percentSum = sumPercents();

  useEffect(() => {
    async function load() {
      try {
        const empRes = await listEmployees();
        const emps = empRes.data || [];
        const empsLevel5 = emps.filter(e => Number(e.empLevel) === 5).map(e => ({ ...e, userId: e.userId || (e._id ? String(e._id) : '') }));
        setEmployeeOptions(empsLevel5);

        setLevel4Options(emps
          .filter(e => Number(e.empLevel) === 4)
          .map(e => ({ empCode: e.empCode, empName: e.empName, userId: e.userId || (e._id ? String(e._id) : '') })));

        const l5 = await listLevel5OKRs();
        setLevel5All(l5.data || []);
      } catch (err) {
        console.error(err);
      }
      setFields(f => ({ ...f, okrDate: getLocalDateString() }));
    }
    load();
  }, []);

  useEffect(() => {
    if (!employeeOptions || !fields.employeeCode) return;
    const emp = employeeOptions.find(x => Number(x.empCode) === Number(fields.employeeCode));
    if (emp && emp.userId && emp.userId !== fields.employeeUserId) {
      setFields(f => ({ ...f, employeeUserId: emp.userId }));
    }
  }, [employeeOptions, fields.employeeCode]);

  useEffect(() => {
    if (!level4Options || !fields.level4EmployeeCode) return;
    const emp = level4Options.find(x => Number(x.empCode) === Number(fields.level4EmployeeCode));
    if (emp && emp.userId && emp.userId !== fields.level4EmployeeUserId) {
      setFields(f => ({ ...f, level4EmployeeUserId: emp.userId }));
    }
  }, [level4Options, fields.level4EmployeeCode]);

  useEffect(() => {
    if (!employeeOptions || !fields.employeeCode) return;
    const emp = employeeOptions.find(x => Number(x.empCode) === Number(fields.employeeCode));
    if (emp && emp.userId && emp.userId !== fields.employeeUserId) {
      setFields(f => ({ ...f, employeeUserId: emp.userId }));
    }
  }, [employeeOptions, fields.employeeCode]);

  const resetForm = () => {
    const newFields = {
      employeeCode: '',
      employeeName: '',
      employeeLevel: '',
      okrCode: '',
      okrDate: getLocalDateString(),
      okrDescription: '',
      keyResults: Array(5).fill(''),
      quarters: [ { percent: '', comment: '' }, { percent: '', comment: '' }, { percent: '', comment: '' }, { percent: '', comment: '' } ],
      level4EmployeeCode: '',
      level4EmployeeName: '',
      level4EmployeeUserId: '',
      level4OKRDescription: '',
      level4OkrCode: ''
    };
    setFields(newFields);
    setLevel5All([]);
    setIsDirty(false);
    pristineRef.current = JSON.stringify(newFields);
  };
  const firstInputRef = useRef(null);
  const tryFocus = () => {
    try {
      const el = firstInputRef.current;
      if (el) {
        el.focus();
        if (typeof el.select === 'function') el.select();
      }
    } catch {}
  };

  useEffect(() => {
    tryFocus();
    const t1 = setTimeout(tryFocus, 50);
    const t2 = setTimeout(tryFocus, 200);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  const handleSelectEmployee = (e) => {
    const code = Number(e.target.value) || '';
    const emp = employeeOptions.find(x => Number(x.empCode) === code);
    setFields(f => ({ ...f, employeeCode: code, employeeName: emp ? emp.empName : '', employeeUserId: emp ? emp.userId : '', employeeLevel: emp ? String(emp.empLevel) : '', okrCode: '' }));
  };

  const handleSelectOKRCode = (e) => {
    const val = e.target.value;
    if (val === 'NEW') {
      const newFields = { ...fields, okrCode: 'NEW', okrDescription: '', keyResults: Array(5).fill(''), quarters: [ { percent: '', comment: '' }, { percent: '', comment: '' }, { percent: '', comment: '' }, { percent: '', comment: '' } ], okrDate: getLocalDateString() };
      setFields(newFields);
      setIsDirty(false);
      pristineRef.current = JSON.stringify(newFields);
      return;
    }
    const num = Number(val);
    const okr = level5All.find(x => Number(x.level5OkrCode) === num || Number(x._id) === num);
    if (!okr) return;
    const newFields = { ...fields, okrCode: okr.level5OkrCode, okrDate: okr.okrDate ? getLocalDateString(okr.okrDate) : fields.okrDate, okrDescription: okr.okrDesc || '', keyResults: [okr.kr1 || '', okr.kr2 || '', okr.kr3 || '', okr.kr4 || '', okr.kr5 || ''], quarters: [ { percent: okr.q1_percentage ?? '', comment: okr.q1_comment || '' }, { percent: okr.q2_percentage ?? '', comment: okr.q2_comment || '' }, { percent: okr.q3_percentage ?? '', comment: okr.q3_comment || '' }, { percent: okr.q4_percentage ?? '', comment: okr.q4_comment || '' } ] };
    setFields(newFields);
    setIsDirty(false);
    pristineRef.current = JSON.stringify(newFields);
  };

  const handleSelectLevel4Employee = (e) => {
    const code = Number(e.target.value) || '';
    const emp = level4Options.find(x => Number(x.empCode) === code);
    setFields(f => ({ ...f, level4EmployeeCode: code, level4EmployeeName: emp ? emp.empName : '', level4EmployeeUserId: emp ? emp.userId : '', level4OKRDescription: '', level4OkrCode: '' }));
    listLevel4OKRs().then(res => {
      const items = (res.data || []).filter(i => Number(i.empCode) === Number(code)).map(i => ({ level4OkrCode: i.level4OkrCode, okrDesc: i.okrDesc || '' }));
      setLevel4OKRDescriptions(items);
    }).catch(() => setLevel4OKRDescriptions([]));
  };

  const handleUpdateOKR = async () => {
    // if (percentSum > 100) { alert('Sum of percentages cannot exceed 100%'); return; }
    // OKR date must not be in the future
    try {
      const okrDate = new Date(`${fields.okrDate}T00:00:00`);
      const today = new Date();
      today.setHours(0,0,0,0);
      if (okrDate > today) { toast.send('OKR Date must not be in the future', 'error'); return; }
    } catch (e) { toast.send('Invalid OKR Date', 'error'); return; }

    if (!fields.level4OkrCode) { toast.send('Please select a Level-4 OKR to link before saving.', 'error'); return; }
    try {
      const payload = {
        empCode: Number(fields.employeeCode),
        empName: fields.employeeName,
        empLevel: Number(fields.employeeLevel) || 5,
        okrDate: fields.okrDate,
        level4OkrCode: fields.level4OkrCode ? Number(fields.level4OkrCode) : undefined,
        okrDesc: fields.okrDescription,
        kr1: fields.keyResults[0] || '',
        kr2: fields.keyResults[1] || '',
        kr3: fields.keyResults[2] || '',
        kr4: fields.keyResults[3] || '',
        kr5: fields.keyResults[4] || '',
        q1_percentage: fields.quarters[0].percent === '' ? undefined : Number(fields.quarters[0].percent),
        q1_comment: fields.quarters[0].comment || '',
        q2_percentage: fields.quarters[1].percent === '' ? undefined : Number(fields.quarters[1].percent),
        q2_comment: fields.quarters[1].comment || '',
        q3_percentage: fields.quarters[2].percent === '' ? undefined : Number(fields.quarters[2].percent),
        q3_comment: fields.quarters[2].comment || '',
        q4_percentage: fields.quarters[3].percent === '' ? undefined : Number(fields.quarters[3].percent),
        q4_comment: fields.quarters[3].comment || ''
      };

      if (fields.okrCode === 'NEW' || fields.okrCode === '' || fields.okrCode == null) {
        const res = await createLevel5OKR(payload);
        const created = res.data;
        toast.send('Created OKR with code: ' + (created.level5OkrCode || created._id), 'success');
        const l5 = await listLevel5OKRs(); setLevel5All(l5.data || []);
        if (created) {
          const newFields = { ...fields, okrCode: created.level5OkrCode || fields.okrCode };
          setFields(newFields);
          setCanClose(true);
          setIsDirty(false);
          pristineRef.current = JSON.stringify(newFields);
        }
      } else {
        await updateLevel5OKR(fields.okrCode, payload);
        toast.send('OKR updated', 'success');
        const l5 = await listLevel5OKRs(); setLevel5All(l5.data || []);
        setCanClose(true);
      }
    } catch (err) { console.error(err); toast.send('Save failed: ' + (err.message || err), 'error'); }
  };

  const handleCancel = () => {
    // behave like Back/Close: navigate immediately to main menu
    navigate('/');
  };

  useEffect(() => {
    if (!_initRef.current) {
      pristineRef.current = JSON.stringify(fields);
      _initRef.current = true;
      setIsDirty(false);
      return;
    }
    setIsDirty(JSON.stringify(fields) !== pristineRef.current);
  }, [fields]);

  return (
    <div className="min-h-screen flex items-center justify-center py-12">
      <div className="absolute top-6 left-6">
        <BackButton onClick={() => navigate('/')} />
      </div>
      <div className="bg-white rounded-lg shadow-2xl w-[95%] max-w-6xl p-8 overflow-hidden professional-panel">
        <h1 className="text-3xl font-bold mb-6 text-center">OKR Workspace - Level 5</h1>
        <form>
          <div className="grid grid-cols-1 gap-4 mb-4 md:grid-cols-2 xl:grid-cols-4">
            <div className="flex flex-col gap-2 min-w-0">
              <label className="font-semibold">Employee</label>
              <select value={fields.employeeCode} onChange={handleSelectEmployee} className="border px-2 py-2 w-full bg-white">
                <option value="">-- Select --</option>
                {employeeOptions.map(emp => (
                  <option key={emp.empCode} value={emp.empCode}>{emp.empName}</option>
                ))}
              </select>
            </div>
            <div className="flex flex-col gap-2 min-w-0">
              <label className="font-semibold">Employee Code</label>
              <input value={fields.employeeUserId} readOnly className="border px-2 py-2 w-full bg-gray-100" />
            </div>
            <div className="flex flex-col gap-2 min-w-0">
              <label className="font-semibold">Employee Level</label>
              <input value={fields.employeeLevel} readOnly className="border px-2 py-2 w-full bg-gray-100" />
            </div>
            <div className="flex flex-col gap-2 min-w-0">
              <label className="font-semibold">Select OKR</label>
              <select value={fields.okrCode} onChange={handleSelectOKRCode} className="border px-2 py-2 w-full">
                <option value="">-- Select --</option>
                <option value="NEW">New</option>
                {level5All
                  .filter(o => Number(o.empCode) === Number(fields.employeeCode))
                  .filter((v,i,a) => a.findIndex(t => String(t.level5OkrCode) === String(v.level5OkrCode)) === i)
                  .map(o => (
                    <option key={o.level5OkrCode} value={o.level5OkrCode}>{o.okrDesc?.slice(0,50) || String(o.level5OkrCode)}</option>
                ))}
              </select>
            </div>
          </div>
          <Box>
            <SectionTitle>Level - 4</SectionTitle>
            <FormRow>
              <div className="w-62">
                <label className="font-semibold block mb-1">Employee Code</label>
                <select ref={firstInputRef} value={fields.level4EmployeeCode} onChange={handleSelectLevel4Employee} className="border px-2 py-1 w-full min-w-0">
                  <option value="">-- Select --</option>
                  {level4Options.map(opt => (
                    <option key={opt.empCode} value={opt.empCode}>{opt.empName}</option>
                  ))}
                </select>
              </div>
              <div className="w-62">
                <label className="font-semibold block mb-1">Employee Code</label>
                <input value={fields.level4EmployeeUserId} readOnly className="border px-2 py-1 w-full bg-gray-100" />
              </div>
              <div className="w-full">
                <label className="font-semibold block mb-1">OKR Description</label>
                <select value={fields.level4OKRDescription} onChange={e => setFields(f => ({ ...f, level4OKRDescription: e.target.value, level4OkrCode: e.target.value && (() => { try { const v = JSON.parse(e.target.selectedOptions[0].dataset.payload); return v.level4OkrCode; } catch { return ''; } })() }))} className="border px-2 py-1 w-full">
                  <option value="">-- Select Description --</option>
                  {level4OKRDescriptions.map((d, i) => (
                    <option key={i} value={d.okrDesc} data-payload={JSON.stringify(d)}>{d.okrDesc}</option>
                  ))}
                </select>
              </div>
            </FormRow>
          </Box>
          <Box>
            <SectionTitle>Level - 5</SectionTitle>
            <div className="flex flex-wrap items-start gap-2 mb-6">
              <div className="flex flex-col items-start gap-1 w-36 min-w-0">
                <label className="font-semibold">OKR Date</label>
                <input type="date" value={fields.okrDate} disabled className="border py-1 w-full bg-gray-100 text-center px-2" />
              </div>
              <div className="flex-1 min-w-0">
                <label className="font-semibold">OKR Description</label>
                <textarea value={fields.okrDescription} onChange={e => setFields(f => ({ ...f, okrDescription: e.target.value }))} className="border w-full h-24 p-2 mt-1 min-w-0" />
              </div>
            </div>
            <div className="mt-8 mb-8">
              {fields.keyResults.map((kr, idx) => (
                <KeyResultInput
                  key={idx}
                  label={`Key Results ${idx + 1}`}
                  value={kr}
                  onChange={e => setFields(f => {
                    const keyResults = [...f.keyResults];
                    keyResults[idx] = e.target.value;
                    return { ...f, keyResults };
                  })}
                />
              ))}
            </div>
          </Box>
              <div className="flex gap-16 mt-8 mb-8">
                <div className="flex-1">
                  <QuarterInput
                    label="Q1 % Completion"
                    value={fields.quarters[0].percent}
                    onChange={e => setFields(f => {
                      const quarters = [...f.quarters];
                      quarters[0].percent = e.target.value;
                      return { ...f, quarters };
                    })}
                    comment={fields.quarters[0].comment}
                    onCommentChange={e => setFields(f => {
                      const quarters = [...f.quarters];
                      quarters[0].comment = e.target.value;
                      return { ...f, quarters };
                    })}
                  />
                  <QuarterInput
                    label="Q2 % Completion"
                    value={fields.quarters[1].percent}
                    onChange={e => setFields(f => {
                      const quarters = [...f.quarters];
                      quarters[1].percent = e.target.value;
                      return { ...f, quarters };
                    })}
                    comment={fields.quarters[1].comment}
                    onCommentChange={e => setFields(f => {
                      const quarters = [...f.quarters];
                      quarters[1].comment = e.target.value;
                      return { ...f, quarters };
                    })}
                  />
                </div>
                <div className="flex-1">
                  <QuarterInput
                    label="Q3 % Completion"
                    value={fields.quarters[2].percent}
                    onChange={e => setFields(f => {
                      const quarters = [...f.quarters];
                      quarters[2].percent = e.target.value;
                      return { ...f, quarters };
                    })}
                    comment={fields.quarters[2].comment}
                    onCommentChange={e => setFields(f => {
                      const quarters = [...f.quarters];
                      quarters[2].comment = e.target.value;
                      return { ...f, quarters };
                    })}
                  />
                  <QuarterInput
                    label="Q4 % Completion"
                    value={fields.quarters[3].percent}
                    onChange={e => setFields(f => {
                      const quarters = [...f.quarters];
                      quarters[3].percent = e.target.value;
                      return { ...f, quarters };
                    })}
                    comment={fields.quarters[3].comment}
                    onCommentChange={e => setFields(f => {
                      const quarters = [...f.quarters];
                      quarters[3].comment = e.target.value;
                      return { ...f, quarters };
                    })}
                  />
                </div>
              </div>
              {/* {percentSum > 100 && (
                <div className="text-red-600 font-semibold text-center">Sum of Q1–Q4 percentages must not exceed 100% (current: {percentSum}%).</div>
              )} */}
              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center mt-8 sm:mt-10">
                <OKRActionButton onClick={(e) => { e.preventDefault(); handleUpdateOKR(); }}>Update OKR</OKRActionButton>
                <OKRActionButton onClick={(e) => { e.preventDefault(); navigate('/'); }}>{(!isDirty || canClose) ? 'Close' : 'Cancel OKR'}</OKRActionButton>
              </div>
        </form>
      </div>
    </div>
  );
};

export default OKRWorkspaceLevel5;
